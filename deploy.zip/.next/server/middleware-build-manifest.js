globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/KdoHL2tkIVPLYWZZm9p5t/_buildManifest.js",
    "static/KdoHL2tkIVPLYWZZm9p5t/_ssgManifest.js",
    "static/KdoHL2tkIVPLYWZZm9p5t/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/10qk6v6416kh8.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/3sx-ag-408v0-.js",
    "static/chunks/2nykiepra7i1k.js",
    "static/chunks/turbopack-3_1zcj--kdz9x.js"
  ]
};
