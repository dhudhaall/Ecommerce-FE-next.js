var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__20ai06_._.js")
R.c("server/chunks/[root-of-the-server]__1w4rv-9._.js")
R.m(62395)
module.exports=R.m(62395).exports
