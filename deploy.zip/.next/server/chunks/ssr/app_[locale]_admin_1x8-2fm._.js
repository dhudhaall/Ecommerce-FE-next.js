module.exports=[34271,a=>{"use strict";let b=["pending","confirmed","preparing","out_for_delivery","delivered"];a.s(["STATUS_FLOW",0,b,"STATUS_LABEL",0,{pending:"Pending",confirmed:"Confirmed",preparing:"Preparing",out_for_delivery:"Out for delivery",delivered:"Delivered",cancelled:"Cancelled"},"STATUS_TABS",0,[{key:"all",label:"All"},{key:"pending",label:"New",statuses:["pending","confirmed"]},{key:"preparing",label:"Preparing",statuses:["preparing"]},{key:"out_for_delivery",label:"Out for delivery",statuses:["out_for_delivery"]},{key:"delivered",label:"Completed",statuses:["delivered"]},{key:"cancelled",label:"Cancelled",statuses:["cancelled"]}],"money",0,(a,b="eur")=>new Intl.NumberFormat("en-IE",{style:"currency",currency:b.toUpperCase()}).format(a),"nextStatus",0,function(a){let c=b.indexOf(a);return -1===c||c===b.length-1?null:b[c+1]},"timeAgo",0,function(a){let b=Math.floor((Date.now()-new Date(a).getTime())/6e4);if(b<1)return"just now";if(b<60)return`${b}m ago`;let c=Math.floor(b/60);return c<24?`${c}h ago`:new Date(a).toLocaleDateString()}])},1908,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(59560),e=a.i(34271);let f="Pizzeria Con Amore",g=`
@page { size: 80mm auto; margin: 0; }
html, body { margin: 0; padding: 0; background: #fff; }
body {
  font-family: ui-monospace, "Courier New", Courier, monospace;
  font-size: 12px;
  line-height: 1.35;
  color: #000;
}
.slip { width: 72mm; padding: 4mm 2mm; page-break-after: always; break-after: page; }
.slip:last-child { page-break-after: auto; break-after: auto; }
.head { text-align: center; }
.store { font-size: 16px; font-weight: 700; letter-spacing: .5px; }
.tag { margin-top: 2px; font-size: 11px; letter-spacing: 2px; }
.line { border-top: 1px solid #000; margin: 6px 0; }
.line.dashed { border-top-style: dashed; }
.order-no { font-size: 18px; font-weight: 700; text-align: center; }
.row-sm { display: flex; justify-content: space-between; font-size: 11px; margin-top: 2px; }
.badge { margin-top: 4px; text-align: center; font-weight: 700; letter-spacing: 1px; }
.item { margin-bottom: 6px; }
.item-top { display: flex; gap: 6px; font-weight: 700; }
.qty { flex: 0 0 auto; }
.name { flex: 1 1 auto; }
.price { flex: 0 0 auto; }
.sub { padding-left: 18px; font-size: 11px; }
.note { padding-left: 18px; font-size: 11px; font-weight: 700; }
.row { display: flex; justify-content: space-between; }
.row.grand { font-size: 15px; font-weight: 700; margin-top: 4px; }
.row.pay { font-size: 11px; margin-top: 4px; }
.cust-name { font-weight: 700; }
.note-label { font-weight: 700; letter-spacing: 1px; }
.order-note { font-weight: 700; }
.foot { text-align: center; font-size: 11px; }
.thanks { margin-top: 4px; font-weight: 700; }
`;function h(a){return String(a??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function i(a,b){let c="kitchen"===b,d=new Date(a.createdAt),g=a.pricing.currency,i=a.items.map(a=>{let b=c?"":`<span class="price">${h((0,e.money)(a.itemTotal,g))}</span>`,d=a.size?`<div class="sub">- ${h(a.size.name)}</div>`:"",f=a.addons.length?`<div class="sub">+ ${h(a.addons.map(a=>a.name).join(", "))}</div>`:"",i=a.notes?`<div class="note">** ${h(a.notes)} **</div>`:"";return`
        <div class="item">
          <div class="item-top">
            <span class="qty">${h(a.quantity)}x</span>
            <span class="name">${h(a.name)}</span>
            ${b}
          </div>
          ${d}${f}${i}
        </div>`}).join(""),j="paid"===a.paymentStatus?"PAID":"cash"===a.paymentMethod?"PAY ON DELIVERY":"UNPAID",k=c?"":`
      <div class="line dashed"></div>
      <div class="totals">
        <div class="row"><span>Subtotal</span><span>${h((0,e.money)(a.pricing.subtotal,g))}</span></div>
        <div class="row"><span>Delivery</span><span>${h((0,e.money)(a.pricing.deliveryFee,g))}</span></div>
        <div class="row grand"><span>TOTAL</span><span>${h((0,e.money)(a.pricing.totalAmount,g))}</span></div>
        <div class="row pay"><span>${h(a.paymentMethod.toUpperCase())}</span><span>${j}</span></div>
      </div>`,l="delivery"===a.delivery.type?`<div>${h(a.delivery.address)}</div>
         <div>${h(a.delivery.city)} ${h(a.delivery.postalCode)}</div>`:"",m=a.notes?`<div class="line dashed"></div>
       <div class="order-note"><div class="note-label">NOTE</div>${h(a.notes)}</div>`:"",n=c?`Status: ${h(e.STATUS_LABEL[a.status])}`:`<div>${h(f)}</div>
       <div>${h("+49 000 000000")}</div>
       <div>${h("Your street, City")}</div>
       <div class="thanks">Thank you for your order!</div>`;return`
    <div class="slip">
      <div class="head">
        <div class="store">${h(f)}</div>
        <div class="tag">${c?"KITCHEN COPY":"CUSTOMER RECEIPT"}</div>
      </div>

      <div class="line"></div>

      <div class="meta">
        <div class="order-no">ORDER #${h(a.id)}</div>
        <div class="row-sm">
          <span>${h(d.toLocaleDateString())}</span>
          <span>${h(d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}))}</span>
        </div>
        <div class="badge">${"pickup"===a.delivery.type?"* PICKUP":"&gt; DELIVERY"}</div>
      </div>

      <div class="line dashed"></div>

      <div class="items">${i}</div>

      ${k}

      <div class="line dashed"></div>

      <div class="cust">
        <div class="cust-name">${h(a.customer.name)}</div>
        <div>${h(a.customer.phone)}</div>
        ${l}
      </div>

      ${m}

      <div class="line"></div>

      <div class="foot">${n}</div>
    </div>`}function j(a,b="both"){let c=[];("kitchen"===b||"both"===b)&&c.push(i(a,"kitchen")),("customer"===b||"both"===b)&&c.push(i(a,"customer"));let d=document.createElement("iframe");d.setAttribute("aria-hidden","true"),d.style.cssText="position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;",document.body.appendChild(d);let e=d.contentDocument;if(!e){d.remove(),console.error("printSlip: could not open iframe document");return}e.open(),e.write(`<!doctype html><html><head><meta charset="utf-8"><title>Order ${a.id}</title><style>${g}</style></head><body>${c.join("")}</body></html>`),e.close();let f=()=>{requestAnimationFrame(()=>{d.contentWindow?.focus(),d.contentWindow?.print(),window.setTimeout(()=>d.remove(),2e3)})};"complete"===e.readyState?f():d.addEventListener("load",f,{once:!0})}var k=a.i(50944);function l(){let a=(0,k.useSearchParams)().get("id"),f=(0,k.useRouter)(),[g,h]=(0,c.useState)(null),[i,l]=(0,c.useState)(!0),[n,o]=(0,c.useState)(""),[p,q]=(0,c.useState)(null),r=async()=>{l(!0),o("");try{let b=await (0,d.api)(`/admin/orders/${a}`);h(b.order)}catch(a){o(a.message||"Failed to load order.")}finally{l(!1)}};(0,c.useEffect)(()=>{r()},[a]);let s=async a=>{if(g){q(a);try{await (0,d.api)(`/admin/orders/${g.id}/status`,{method:"PATCH",body:{status:a}}),h({...g,status:a})}catch(a){o(a.message||"Could not update status.")}finally{q(null)}}};if(i)return(0,b.jsx)("div",{className:"ad-page",children:(0,b.jsxs)("div",{className:"ad-state",children:[(0,b.jsx)("span",{className:"ad-spinner"})," Loading order…"]})});if(n||!g)return(0,b.jsxs)("div",{className:"ad-page",children:[(0,b.jsx)("button",{type:"button",className:"ad-back",onClick:()=>f.push("/admin/orders"),children:"‹ Back to orders"}),(0,b.jsxs)("div",{className:"ad-state",children:[(0,b.jsx)("p",{className:"ad-err-text",children:n||"Order not found."}),(0,b.jsx)("button",{type:"button",className:"ad-btn ghost",onClick:r,children:"Try again"})]})]});let t=(0,e.nextStatus)(g.status),u="cash"!==g.paymentMethod&&"paid"!==g.paymentStatus,v=e.STATUS_FLOW.indexOf(g.status);return(0,b.jsxs)("div",{className:"ad-page",children:[(0,b.jsx)("button",{type:"button",className:"ad-back",onClick:()=>f.push("/admin/orders"),children:"‹ Back to orders"}),(0,b.jsxs)("div",{className:"ad-detail-head",children:[(0,b.jsxs)("div",{children:[(0,b.jsxs)("h1",{children:["Order #",g.id]}),(0,b.jsxs)("p",{className:"ad-page-sub",children:[new Date(g.createdAt).toLocaleString()," · ","pickup"===g.delivery.type?"Pickup":"Delivery"]})]}),(0,b.jsxs)("div",{className:"ad-detail-head-right",children:[(0,b.jsxs)("div",{className:"ad-print-group",children:[(0,b.jsxs)("button",{type:"button",className:"ad-btn ghost",onClick:()=>j(g,"kitchen"),children:[(0,b.jsx)(m,{})," Kitchen slip"]}),(0,b.jsxs)("button",{type:"button",className:"ad-btn ghost",onClick:()=>j(g,"customer"),children:[(0,b.jsx)(m,{})," Customer receipt"]})]}),(0,b.jsx)("span",{className:`ad-badge lg status-${g.status}`,children:e.STATUS_LABEL[g.status]})]})]}),u&&(0,b.jsxs)("div",{className:"ad-warn",children:["⚠ This is a card order that is ",(0,b.jsx)("strong",{children:"not paid yet"})," — do not prepare until payment is confirmed."]}),(0,b.jsxs)("div",{className:"ad-card",children:[(0,b.jsx)("div",{className:"ad-card-title",children:"Order status"}),(0,b.jsx)("div",{className:"ad-progress",children:e.STATUS_FLOW.map((a,c)=>(0,b.jsxs)("div",{className:`ad-step ${c<=v?"done":""} ${c===v?"current":""}`,children:[(0,b.jsx)("span",{className:"ad-step-dot",children:c<v?"✓":c+1}),(0,b.jsx)("span",{className:"ad-step-label",children:e.STATUS_LABEL[a]})]},a))}),(0,b.jsx)("div",{className:"ad-status-actions",children:"cancelled"===g.status?(0,b.jsx)("span",{className:"ad-muted",children:"This order was cancelled."}):"delivered"===g.status?(0,b.jsx)("span",{className:"ad-done-msg",children:"✓ Order completed."}):(0,b.jsxs)(b.Fragment,{children:[t&&(0,b.jsx)("button",{type:"button",className:"ad-btn primary",onClick:()=>s(t),disabled:!!p,children:p===t?(0,b.jsx)("span",{className:"ad-spinner light"}):`Mark as ${e.STATUS_LABEL[t]}`}),(0,b.jsx)("button",{type:"button",className:"ad-btn danger-ghost",onClick:()=>s("cancelled"),disabled:!!p,children:"cancelled"===p?(0,b.jsx)("span",{className:"ad-spinner"}):"Cancel order"})]})})]}),(0,b.jsxs)("div",{className:"ad-detail-grid",children:[(0,b.jsxs)("div",{className:"ad-card",children:[(0,b.jsxs)("div",{className:"ad-card-title",children:["Items (",g.items.length,")"]}),g.items.map(a=>(0,b.jsxs)("div",{className:"ad-item",children:[(0,b.jsxs)("div",{className:"ad-item-qty",children:[a.quantity,"×"]}),(0,b.jsxs)("div",{className:"ad-item-body",children:[(0,b.jsx)("div",{className:"ad-item-name",children:a.name}),a.size&&(0,b.jsxs)("div",{className:"ad-item-line",children:["Size: ",a.size.name]}),a.addons.length>0&&(0,b.jsxs)("div",{className:"ad-item-line",children:["Add-ons: ",a.addons.map(a=>a.name).join(", ")]}),a.notes&&(0,b.jsxs)("div",{className:"ad-item-note",children:["📝 ",a.notes]})]}),(0,b.jsx)("div",{className:"ad-item-price",children:(0,e.money)(a.itemTotal,g.pricing.currency)})]},a.id)),(0,b.jsxs)("div",{className:"ad-totals",children:[(0,b.jsxs)("div",{className:"ad-total-row",children:[(0,b.jsx)("span",{children:"Subtotal"}),(0,b.jsx)("span",{children:(0,e.money)(g.pricing.subtotal,g.pricing.currency)})]}),(0,b.jsxs)("div",{className:"ad-total-row",children:[(0,b.jsx)("span",{children:"Delivery fee"}),(0,b.jsx)("span",{children:(0,e.money)(g.pricing.deliveryFee,g.pricing.currency)})]}),(0,b.jsxs)("div",{className:"ad-total-row grand",children:[(0,b.jsx)("span",{children:"Total"}),(0,b.jsx)("span",{children:(0,e.money)(g.pricing.totalAmount,g.pricing.currency)})]})]})]}),(0,b.jsxs)("div",{className:"ad-card",children:[(0,b.jsx)("div",{className:"ad-card-title",children:"Customer"}),(0,b.jsxs)("dl",{className:"ad-info",children:[(0,b.jsx)("dt",{children:"Name"}),(0,b.jsx)("dd",{children:g.customer.name}),(0,b.jsx)("dt",{children:"Phone"}),(0,b.jsx)("dd",{children:(0,b.jsx)("a",{href:`tel:${g.customer.phone}`,children:g.customer.phone})}),(0,b.jsx)("dt",{children:"Email"}),(0,b.jsx)("dd",{children:g.customer.email})]}),(0,b.jsx)("div",{className:"ad-card-title mt",children:"pickup"===g.delivery.type?"Pickup":"Delivery address"}),"pickup"===g.delivery.type?(0,b.jsx)("p",{className:"ad-muted",children:"Customer will collect this order."}):(0,b.jsxs)("dl",{className:"ad-info",children:[(0,b.jsx)("dt",{children:"Address"}),(0,b.jsx)("dd",{children:g.delivery.address}),(0,b.jsx)("dt",{children:"City"}),(0,b.jsx)("dd",{children:g.delivery.city}),(0,b.jsx)("dt",{children:"Postal"}),(0,b.jsx)("dd",{children:g.delivery.postalCode})]}),(0,b.jsx)("div",{className:"ad-card-title mt",children:"Payment"}),(0,b.jsxs)("dl",{className:"ad-info",children:[(0,b.jsx)("dt",{children:"Method"}),(0,b.jsx)("dd",{style:{textTransform:"capitalize"},children:g.paymentMethod}),(0,b.jsx)("dt",{children:"Status"}),(0,b.jsx)("dd",{children:(0,b.jsx)("span",{className:`ad-badge ${"paid"===g.paymentStatus?"pay-paid":"failed"===g.paymentStatus?"pay-failed":"cash"===g.paymentMethod?"pay-cod":"pay-unpaid"}`,children:"paid"===g.paymentStatus?"Paid":"failed"===g.paymentStatus?"Failed":"cash"===g.paymentMethod?"Cash (COD)":"Unpaid"})})]}),g.notes&&(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("div",{className:"ad-card-title mt",children:"Order notes"}),(0,b.jsxs)("p",{className:"ad-item-note block",children:["📝 ",g.notes]})]})]})]})]})}function m(){return(0,b.jsxs)("svg",{width:"15",height:"15",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8","aria-hidden":!0,children:[(0,b.jsx)("path",{d:"M6 9V2h12v7"}),(0,b.jsx)("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"}),(0,b.jsx)("rect",{x:"6",y:"14",width:"12",height:"8"})]})}a.s(["default",0,function(){return(0,b.jsx)(c.Suspense,{fallback:(0,b.jsx)("div",{children:"Loading…"}),children:(0,b.jsx)(l,{})})}],1908)}];

//# sourceMappingURL=app_%5Blocale%5D_admin_1x8-2fm._.js.map