module.exports=[87687,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_admin_orders_details_page_actions_0r2i143.js.map