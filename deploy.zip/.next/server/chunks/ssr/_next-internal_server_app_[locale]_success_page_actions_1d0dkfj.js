module.exports=[21222,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_success_page_actions_1d0dkfj.js.map