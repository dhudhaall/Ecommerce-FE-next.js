module.exports=[86987,(a,b,c)=>{b.exports={Navbar:{home:"Home",products:"Products",about:"About",contact:"Contact"},HomePage:{title_1:"Essen Bestellen",title_2:"Und Mehr",sub_title:"Frisch aus unserer Küche, in Ihre Nähe geliefert"}}}];

//# sourceMappingURL=messages_de_json_%5Bjson%5D_cjs_1uig1ud._.js.map