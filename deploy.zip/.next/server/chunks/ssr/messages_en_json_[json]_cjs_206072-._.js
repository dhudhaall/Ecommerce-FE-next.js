module.exports=[45983,(a,b,c)=>{b.exports={Navbar:{home:"Home",products:"Products",about:"About",contact:"Contact"},HomePage:{title_1:"Order food",title_2:"and more",sub_title:"Fresh from our kitchen, delivered to your area"}}}];

//# sourceMappingURL=messages_en_json_%5Bjson%5D_cjs_206072-._.js.map