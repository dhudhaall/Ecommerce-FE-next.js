(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,17362,e=>{"use strict";let s=["pending","confirmed","preparing","out_for_delivery","delivered"];e.s(["STATUS_FLOW",0,s,"STATUS_LABEL",0,{pending:"Pending",confirmed:"Confirmed",preparing:"Preparing",out_for_delivery:"Out for delivery",delivered:"Delivered",cancelled:"Cancelled"},"STATUS_TABS",0,[{key:"all",label:"All"},{key:"pending",label:"New",statuses:["pending","confirmed"]},{key:"preparing",label:"Preparing",statuses:["preparing"]},{key:"out_for_delivery",label:"Out for delivery",statuses:["out_for_delivery"]},{key:"delivered",label:"Completed",statuses:["delivered"]},{key:"cancelled",label:"Cancelled",statuses:["cancelled"]}],"money",0,(e,s="eur")=>new Intl.NumberFormat("en-IE",{style:"currency",currency:s.toUpperCase()}).format(e),"nextStatus",0,function(e){let a=s.indexOf(e);return -1===a||a===s.length-1?null:s[a+1]},"timeAgo",0,function(e){let s=Math.floor((Date.now()-new Date(e).getTime())/6e4);if(s<1)return"just now";if(s<60)return`${s}m ago`;let a=Math.floor(s/60);return a<24?`${a}h ago`:new Date(e).toLocaleDateString()}])},60816,e=>{"use strict";var s=e.i(43476),a=e.i(71645),t=e.i(86289),i=e.i(17362);let d="Pizzeria Con Amore",n=`
@page { size: 80mm auto; margin: 0; }
html, body { margin: 0; padding: 0; background: #fff; }
body {
  font-family: ui-monospace, "Courier New", Courier, monospace;
  font-size: 12px;
  line-height: 1.35;
  color: #000;
}
.slip { width: 72mm; padding: 4mm 2mm; page-break-after: always; break-after: page; }
.slip:last-child { page-break-after: auto; break-after: auto; }
.head { text-align: center; }
.store { font-size: 16px; font-weight: 700; letter-spacing: .5px; }
.tag { margin-top: 2px; font-size: 11px; letter-spacing: 2px; }
.line { border-top: 1px solid #000; margin: 6px 0; }
.line.dashed { border-top-style: dashed; }
.order-no { font-size: 18px; font-weight: 700; text-align: center; }
.row-sm { display: flex; justify-content: space-between; font-size: 11px; margin-top: 2px; }
.badge { margin-top: 4px; text-align: center; font-weight: 700; letter-spacing: 1px; }
.item { margin-bottom: 6px; }
.item-top { display: flex; gap: 6px; font-weight: 700; }
.qty { flex: 0 0 auto; }
.name { flex: 1 1 auto; }
.price { flex: 0 0 auto; }
.sub { padding-left: 18px; font-size: 11px; }
.note { padding-left: 18px; font-size: 11px; font-weight: 700; }
.row { display: flex; justify-content: space-between; }
.row.grand { font-size: 15px; font-weight: 700; margin-top: 4px; }
.row.pay { font-size: 11px; margin-top: 4px; }
.cust-name { font-weight: 700; }
.note-label { font-weight: 700; letter-spacing: 1px; }
.order-note { font-weight: 700; }
.foot { text-align: center; font-size: 11px; }
.thanks { margin-top: 4px; font-weight: 700; }
`;function l(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function r(e,s){let a="kitchen"===s,t=new Date(e.createdAt),n=e.pricing.currency,r=e.items.map(e=>{let s=a?"":`<span class="price">${l((0,i.money)(e.itemTotal,n))}</span>`,t=e.size?`<div class="sub">- ${l(e.size.name)}</div>`:"",d=e.addons.length?`<div class="sub">+ ${l(e.addons.map(e=>e.name).join(", "))}</div>`:"",r=e.notes?`<div class="note">** ${l(e.notes)} **</div>`:"";return`
        <div class="item">
          <div class="item-top">
            <span class="qty">${l(e.quantity)}x</span>
            <span class="name">${l(e.name)}</span>
            ${s}
          </div>
          ${t}${d}${r}
        </div>`}).join(""),c="paid"===e.paymentStatus?"PAID":"cash"===e.paymentMethod?"PAY ON DELIVERY":"UNPAID",o=a?"":`
      <div class="line dashed"></div>
      <div class="totals">
        <div class="row"><span>Subtotal</span><span>${l((0,i.money)(e.pricing.subtotal,n))}</span></div>
        <div class="row"><span>Delivery</span><span>${l((0,i.money)(e.pricing.deliveryFee,n))}</span></div>
        <div class="row grand"><span>TOTAL</span><span>${l((0,i.money)(e.pricing.totalAmount,n))}</span></div>
        <div class="row pay"><span>${l(e.paymentMethod.toUpperCase())}</span><span>${c}</span></div>
      </div>`,p="delivery"===e.delivery.type?`<div>${l(e.delivery.address)}</div>
         <div>${l(e.delivery.city)} ${l(e.delivery.postalCode)}</div>`:"",m=e.notes?`<div class="line dashed"></div>
       <div class="order-note"><div class="note-label">NOTE</div>${l(e.notes)}</div>`:"",h=a?`Status: ${l(i.STATUS_LABEL[e.status])}`:`<div>${l(d)}</div>
       <div>${l("+49 000 000000")}</div>
       <div>${l("Your street, City")}</div>
       <div class="thanks">Thank you for your order!</div>`;return`
    <div class="slip">
      <div class="head">
        <div class="store">${l(d)}</div>
        <div class="tag">${a?"KITCHEN COPY":"CUSTOMER RECEIPT"}</div>
      </div>

      <div class="line"></div>

      <div class="meta">
        <div class="order-no">ORDER #${l(e.id)}</div>
        <div class="row-sm">
          <span>${l(t.toLocaleDateString())}</span>
          <span>${l(t.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}))}</span>
        </div>
        <div class="badge">${"pickup"===e.delivery.type?"* PICKUP":"&gt; DELIVERY"}</div>
      </div>

      <div class="line dashed"></div>

      <div class="items">${r}</div>

      ${o}

      <div class="line dashed"></div>

      <div class="cust">
        <div class="cust-name">${l(e.customer.name)}</div>
        <div>${l(e.customer.phone)}</div>
        ${p}
      </div>

      ${m}

      <div class="line"></div>

      <div class="foot">${h}</div>
    </div>`}function c(e,s="both"){let a=[];("kitchen"===s||"both"===s)&&a.push(r(e,"kitchen")),("customer"===s||"both"===s)&&a.push(r(e,"customer"));let t=document.createElement("iframe");t.setAttribute("aria-hidden","true"),t.style.cssText="position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;",document.body.appendChild(t);let i=t.contentDocument;if(!i){t.remove(),console.error("printSlip: could not open iframe document");return}i.open(),i.write(`<!doctype html><html><head><meta charset="utf-8"><title>Order ${e.id}</title><style>${n}</style></head><body>${a.join("")}</body></html>`),i.close();let d=()=>{requestAnimationFrame(()=>{t.contentWindow?.focus(),t.contentWindow?.print(),window.setTimeout(()=>t.remove(),2e3)})};"complete"===i.readyState?d():t.addEventListener("load",d,{once:!0})}var o=e.i(18566);function p(){let e=(0,o.useSearchParams)().get("id"),d=(0,o.useRouter)(),[n,l]=(0,a.useState)(null),[r,p]=(0,a.useState)(!0),[h,u]=(0,a.useState)(""),[v,x]=(0,a.useState)(null),g=async()=>{p(!0),u("");try{let s=await (0,t.api)(`/admin/orders/${e}`);l(s.order)}catch(e){u(e.message||"Failed to load order.")}finally{p(!1)}};(0,a.useEffect)(()=>{g()},[e]);let y=async e=>{if(n){x(e);try{await (0,t.api)(`/admin/orders/${n.id}/status`,{method:"PATCH",body:{status:e}}),l({...n,status:e})}catch(e){u(e.message||"Could not update status.")}finally{x(null)}}};if(r)return(0,s.jsx)("div",{className:"ad-page",children:(0,s.jsxs)("div",{className:"ad-state",children:[(0,s.jsx)("span",{className:"ad-spinner"})," Loading order…"]})});if(h||!n)return(0,s.jsxs)("div",{className:"ad-page",children:[(0,s.jsx)("button",{type:"button",className:"ad-back",onClick:()=>d.push("/admin/orders"),children:"‹ Back to orders"}),(0,s.jsxs)("div",{className:"ad-state",children:[(0,s.jsx)("p",{className:"ad-err-text",children:h||"Order not found."}),(0,s.jsx)("button",{type:"button",className:"ad-btn ghost",onClick:g,children:"Try again"})]})]});let j=(0,i.nextStatus)(n.status),f="cash"!==n.paymentMethod&&"paid"!==n.paymentStatus,b=i.STATUS_FLOW.indexOf(n.status);return(0,s.jsxs)("div",{className:"ad-page",children:[(0,s.jsx)("button",{type:"button",className:"ad-back",onClick:()=>d.push("/admin/orders"),children:"‹ Back to orders"}),(0,s.jsxs)("div",{className:"ad-detail-head",children:[(0,s.jsxs)("div",{children:[(0,s.jsxs)("h1",{children:["Order #",n.id]}),(0,s.jsxs)("p",{className:"ad-page-sub",children:[new Date(n.createdAt).toLocaleString()," · ","pickup"===n.delivery.type?"Pickup":"Delivery"]})]}),(0,s.jsxs)("div",{className:"ad-detail-head-right",children:[(0,s.jsxs)("div",{className:"ad-print-group",children:[(0,s.jsxs)("button",{type:"button",className:"ad-btn ghost",onClick:()=>c(n,"kitchen"),children:[(0,s.jsx)(m,{})," Kitchen slip"]}),(0,s.jsxs)("button",{type:"button",className:"ad-btn ghost",onClick:()=>c(n,"customer"),children:[(0,s.jsx)(m,{})," Customer receipt"]})]}),(0,s.jsx)("span",{className:`ad-badge lg status-${n.status}`,children:i.STATUS_LABEL[n.status]})]})]}),f&&(0,s.jsxs)("div",{className:"ad-warn",children:["⚠ This is a card order that is ",(0,s.jsx)("strong",{children:"not paid yet"})," — do not prepare until payment is confirmed."]}),(0,s.jsxs)("div",{className:"ad-card",children:[(0,s.jsx)("div",{className:"ad-card-title",children:"Order status"}),(0,s.jsx)("div",{className:"ad-progress",children:i.STATUS_FLOW.map((e,a)=>(0,s.jsxs)("div",{className:`ad-step ${a<=b?"done":""} ${a===b?"current":""}`,children:[(0,s.jsx)("span",{className:"ad-step-dot",children:a<b?"✓":a+1}),(0,s.jsx)("span",{className:"ad-step-label",children:i.STATUS_LABEL[e]})]},e))}),(0,s.jsx)("div",{className:"ad-status-actions",children:"cancelled"===n.status?(0,s.jsx)("span",{className:"ad-muted",children:"This order was cancelled."}):"delivered"===n.status?(0,s.jsx)("span",{className:"ad-done-msg",children:"✓ Order completed."}):(0,s.jsxs)(s.Fragment,{children:[j&&(0,s.jsx)("button",{type:"button",className:"ad-btn primary",onClick:()=>y(j),disabled:!!v,children:v===j?(0,s.jsx)("span",{className:"ad-spinner light"}):`Mark as ${i.STATUS_LABEL[j]}`}),(0,s.jsx)("button",{type:"button",className:"ad-btn danger-ghost",onClick:()=>y("cancelled"),disabled:!!v,children:"cancelled"===v?(0,s.jsx)("span",{className:"ad-spinner"}):"Cancel order"})]})})]}),(0,s.jsxs)("div",{className:"ad-detail-grid",children:[(0,s.jsxs)("div",{className:"ad-card",children:[(0,s.jsxs)("div",{className:"ad-card-title",children:["Items (",n.items.length,")"]}),n.items.map(e=>(0,s.jsxs)("div",{className:"ad-item",children:[(0,s.jsxs)("div",{className:"ad-item-qty",children:[e.quantity,"×"]}),(0,s.jsxs)("div",{className:"ad-item-body",children:[(0,s.jsx)("div",{className:"ad-item-name",children:e.name}),e.size&&(0,s.jsxs)("div",{className:"ad-item-line",children:["Size: ",e.size.name]}),e.addons.length>0&&(0,s.jsxs)("div",{className:"ad-item-line",children:["Add-ons: ",e.addons.map(e=>e.name).join(", ")]}),e.notes&&(0,s.jsxs)("div",{className:"ad-item-note",children:["📝 ",e.notes]})]}),(0,s.jsx)("div",{className:"ad-item-price",children:(0,i.money)(e.itemTotal,n.pricing.currency)})]},e.id)),(0,s.jsxs)("div",{className:"ad-totals",children:[(0,s.jsxs)("div",{className:"ad-total-row",children:[(0,s.jsx)("span",{children:"Subtotal"}),(0,s.jsx)("span",{children:(0,i.money)(n.pricing.subtotal,n.pricing.currency)})]}),(0,s.jsxs)("div",{className:"ad-total-row",children:[(0,s.jsx)("span",{children:"Delivery fee"}),(0,s.jsx)("span",{children:(0,i.money)(n.pricing.deliveryFee,n.pricing.currency)})]}),(0,s.jsxs)("div",{className:"ad-total-row grand",children:[(0,s.jsx)("span",{children:"Total"}),(0,s.jsx)("span",{children:(0,i.money)(n.pricing.totalAmount,n.pricing.currency)})]})]})]}),(0,s.jsxs)("div",{className:"ad-card",children:[(0,s.jsx)("div",{className:"ad-card-title",children:"Customer"}),(0,s.jsxs)("dl",{className:"ad-info",children:[(0,s.jsx)("dt",{children:"Name"}),(0,s.jsx)("dd",{children:n.customer.name}),(0,s.jsx)("dt",{children:"Phone"}),(0,s.jsx)("dd",{children:(0,s.jsx)("a",{href:`tel:${n.customer.phone}`,children:n.customer.phone})}),(0,s.jsx)("dt",{children:"Email"}),(0,s.jsx)("dd",{children:n.customer.email})]}),(0,s.jsx)("div",{className:"ad-card-title mt",children:"pickup"===n.delivery.type?"Pickup":"Delivery address"}),"pickup"===n.delivery.type?(0,s.jsx)("p",{className:"ad-muted",children:"Customer will collect this order."}):(0,s.jsxs)("dl",{className:"ad-info",children:[(0,s.jsx)("dt",{children:"Address"}),(0,s.jsx)("dd",{children:n.delivery.address}),(0,s.jsx)("dt",{children:"City"}),(0,s.jsx)("dd",{children:n.delivery.city}),(0,s.jsx)("dt",{children:"Postal"}),(0,s.jsx)("dd",{children:n.delivery.postalCode})]}),(0,s.jsx)("div",{className:"ad-card-title mt",children:"Payment"}),(0,s.jsxs)("dl",{className:"ad-info",children:[(0,s.jsx)("dt",{children:"Method"}),(0,s.jsx)("dd",{style:{textTransform:"capitalize"},children:n.paymentMethod}),(0,s.jsx)("dt",{children:"Status"}),(0,s.jsx)("dd",{children:(0,s.jsx)("span",{className:`ad-badge ${"paid"===n.paymentStatus?"pay-paid":"failed"===n.paymentStatus?"pay-failed":"cash"===n.paymentMethod?"pay-cod":"pay-unpaid"}`,children:"paid"===n.paymentStatus?"Paid":"failed"===n.paymentStatus?"Failed":"cash"===n.paymentMethod?"Cash (COD)":"Unpaid"})})]}),n.notes&&(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)("div",{className:"ad-card-title mt",children:"Order notes"}),(0,s.jsxs)("p",{className:"ad-item-note block",children:["📝 ",n.notes]})]})]})]})]})}function m(){return(0,s.jsxs)("svg",{width:"15",height:"15",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8","aria-hidden":!0,children:[(0,s.jsx)("path",{d:"M6 9V2h12v7"}),(0,s.jsx)("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"}),(0,s.jsx)("rect",{x:"6",y:"14",width:"12",height:"8"})]})}e.s(["default",0,function(){return(0,s.jsx)(a.Suspense,{fallback:(0,s.jsx)("div",{children:"Loading…"}),children:(0,s.jsx)(p,{})})}],60816)}]);